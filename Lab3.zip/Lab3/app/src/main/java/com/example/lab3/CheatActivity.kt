package com.example.lab3

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
public const val EXTRA_ANSWER_IS_TRUE = "com.example.lab3.answer_is_true"

class CheatActivity : AppCompatActivity() {

    private var answerIsTrue=false
    private lateinit var showAnswerButton: Button

    companion object{
        fun newIntent(packageContext: Context, answerIsTrue: Boolean):Intent{
            return Intent(packageContext, CheatActivity::class.java).apply {
                putExtra(EXTRA_ANSWER_IS_TRUE, answerIsTrue)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        answerIsTrue=intent?.getBooleanExtra(EXTRA_ANSWER_IS_TRUE, false)?:false
        setContentView(R.layout.activity_cheat)

        val answerTextView=findViewById<TextView>(R.id.tvAnswer)
        answerTextView.visibility=View.INVISIBLE
        val answerText=when{
            answerIsTrue -> R.string.true_text
            else -> R.string.false_text
        }
        answerTextView.setText(answerText)

        showAnswerButton=findViewById(R.id.btnShow)
        showAnswerButton.setOnClickListener {
            answerTextView.visibility=View.VISIBLE
            showAnswerButton.visibility= View.GONE
        }
    }
}