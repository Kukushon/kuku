package com.example.lab3

import androidx.lifecycle.ViewModel

class MainActivityViewModel : ViewModel() {
    private val questionBank=listOf(
        Question(R.string.question_australia, true),
        Question(R.string.question_oceans, true),
        Question(R.string.question_mideast, true),
        Question(R.string.question_africa, true),
        Question(R.string.question_americas, true),
        Question(R.string.question_asia, true),
        Question(R.string.question_russia, false),
    )

    private var currentIndex=0;

    val currentQuestionAnswer: Boolean
        get()=questionBank[currentIndex].answer
    val currentQuestionText: Int
        get()=questionBank[currentIndex].textResId

    fun moveToNext(){
        currentIndex=(currentIndex+1)%questionBank.size
    }

    fun moveToPrev(){
        currentIndex=(questionBank.size+currentIndex-1)%questionBank.size
    }
}